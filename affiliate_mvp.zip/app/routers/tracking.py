from fastapi import APIRouter

router = APIRouter(prefix="/track", tags=["tracking"])

@router.post("/click")
def track_click():
    return {"msg": "Click tracked"}

@router.post("/conversion")
def track_conversion():
    return {"msg": "Conversion tracked"}