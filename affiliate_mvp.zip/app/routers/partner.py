from fastapi import APIRouter

router = APIRouter(prefix="/partner", tags=["partner"])

@router.get("/dashboard")
def get_dashboard():
    return {"msg": "Partner dashboard"}