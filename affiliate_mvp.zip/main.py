from fastapi import FastAPI
from app.routers import auth, tracking, partner

app = FastAPI()

app.include_router(auth.router)
app.include_router(tracking.router)
app.include_router(partner.router)